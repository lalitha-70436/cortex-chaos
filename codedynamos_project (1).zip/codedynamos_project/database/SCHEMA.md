# CodeDynamos — Database Schema

This project uses JSON file storage by default (for easy portability).
For production, replace the `Database` class in `backend/database.js`
with a MongoDB or PostgreSQL adapter.

---

## Tables / Collections

### users
| Field        | Type     | Description                          |
|--------------|----------|--------------------------------------|
| name         | string   | Full name                            |
| handle       | string   | Unique username (PK)                 |
| email        | string   | College email                        |
| password     | string   | Plain text (hash in production!)     |
| role         | string   | 'member' \| 'admin'                  |
| score        | number   | Total XP                             |
| submissions  | number   | Number of challenge submissions      |
| events       | number   | Number of events attended            |
| rank         | number   | Leaderboard rank                     |
| badges       | string[] | Earned badge emojis                  |
| avatar       | string   | Emoji avatar                         |
| color        | string   | Profile background color (RGBA)      |
| points       | number   | Contribution points                  |
| domain       | string   | Tech domain (Web, AI/ML, Design)     |
| joinDate     | string   | Join date                            |
| banned       | boolean  | Account suspended flag               |

### events
| Field           | Type    | Description                        |
|-----------------|---------|------------------------------------|
| id              | number  | Auto-increment ID (PK)             |
| title           | string  | Event name                         |
| category        | string  | Workshop / Hackathon / Talk / etc  |
| date            | string  | Display date string                |
| time            | string  | Start time                         |
| venue           | string  | Location or online link            |
| mode            | string  | 'offline' \| 'online'              |
| banner          | string  | Emoji banner                       |
| color           | string  | CSS gradient for card background   |
| registrations   | number  | Current registration count         |
| maxReg          | number  | Max capacity                       |
| status          | string  | 'upcoming' \| 'past'               |
| description     | string  | Full description                   |
| feedbackEnabled | boolean | Whether feedback is open           |
| winner          | string  | (optional) Winner name for past    |

### challenges
| Field       | Type   | Description                               |
|-------------|--------|-------------------------------------------|
| id          | number | Auto-increment ID (PK)                    |
| title       | string | Challenge name                            |
| difficulty  | string | 'Easy' \| 'Medium' \| 'Hard'             |
| category    | string | UI/UX / Full-Stack / API Design / etc     |
| deadline    | string | Deadline display string                   |
| submissions | number | Number of submissions                     |
| status      | string | 'live' \| 'upcoming' \| 'closed'          |
| desc        | string | Full description                          |

### submissions
| Field       | Type   | Description                               |
|-------------|--------|-------------------------------------------|
| id          | number | Timestamp-based ID (PK)                   |
| challengeId | number | FK → challenges.id                        |
| userId      | string | FK → users.handle                         |
| githubUrl   | string | GitHub repository URL                     |
| liveUrl     | string | Live deployment URL (optional)            |
| desc        | string | Submission description                    |
| date        | string | Submission date                           |
| status      | string | 'pending' \| 'reviewed'                   |
| score       | number | Admin-assigned score (null if pending)    |

### projects
| Field    | Type     | Description                            |
|----------|----------|----------------------------------------|
| id       | number   | Auto-increment ID (PK)                 |
| title    | string   | Project name                           |
| domain   | string   | Web / AI/ML / Mobile / Design          |
| year     | string   | Year built                             |
| emoji    | string   | Emoji icon                             |
| color    | string   | CSS gradient for banner                |
| stack    | string[] | Tech stack list                        |
| team     | string[] | Team members display names             |
| featured | boolean  | Pinned to top                          |
| likes    | number   | Like count                             |
| desc     | string   | Project description                    |

### team
| Field   | Type     | Description                            |
|---------|----------|----------------------------------------|
| name    | string   | Full name                              |
| role    | string   | Club Lead / Core Team / Member / Alumni|
| domain  | string   | Tech domain                            |
| batch   | string   | Year of batch                          |
| emoji   | string   | Emoji avatar                           |
| color   | string   | Card background color                  |
| skills  | string[] | Skill tags                             |
| alumni  | boolean  | Alumni flag                            |
| tier    | string   | 'lead' \| 'core' \| 'member' \| 'alumni' |
| points  | number   | Contribution points                    |

### leaderboard
| Field       | Type   | Description                   |
|-------------|--------|-------------------------------|
| name        | string | Full name                     |
| handle      | string | FK → users.handle             |
| score       | number | XP score                      |
| submissions | number | Challenge submissions          |
| badge       | string | Badge emoji                   |
| rank        | number | Current rank                  |
| color       | string | Row highlight color            |
| emoji       | string | Avatar emoji                  |

### suggestions
| Field    | Type   | Description                                  |
|----------|--------|----------------------------------------------|
| id       | number | Auto-increment ID (PK)                       |
| title    | string | Suggestion title                             |
| category | string | Competition / Workshop / Bootcamp / Hackathon|
| desc     | string | Full description                             |
| by       | string | Author handle (@handle)                      |
| votes    | number | Upvote count                                 |
| status   | string | 'pending' \| 'considering' \| 'approved' \| 'rejected' |

### feedbackSubmissions
| Field   | Type   | Description                   |
|---------|--------|-------------------------------|
| id      | number | Timestamp-based ID (PK)       |
| eventId | number | FK → events.id                |
| userId  | string | FK → users.handle             |
| event   | string | Event title (denormalized)    |
| by      | string | Author @handle                |
| rating  | number | 1–5 star rating               |
| comment | string | Written feedback              |
| date    | string | Submission date               |

### certificates
| Field | Type   | Description          |
|-------|--------|----------------------|
| id    | number | ID (PK)              |
| event | string | Event name           |
| date  | string | Issue date           |
| type  | string | Participation / Completion / Achievement |
| icon  | string | Emoji icon           |

### announcements
| Field    | Type   | Description                      |
|----------|--------|----------------------------------|
| id       | number | Timestamp-based ID (PK)          |
| title    | string | Announcement heading             |
| message  | string | Body text                        |
| priority | string | 'Normal' \| 'Important' \| 'Urgent' |
| date     | string | Posted date                      |

### registrations (object / map)
```json
{
  "<eventId>": ["handle1", "handle2", ...]
}
```

### votes (object / map)
```json
{
  "<suggestionId>_<userId>": true
}
```

### likes (object / map)
```json
{
  "<projectId>_<userId>": true
}
```

---

## Upgrading to PostgreSQL

Replace `backend/database.js` with a pg-based adapter:

```js
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
```

All method signatures in the `Database` class remain the same —
only the internal read/write implementation changes.

## Upgrading to MongoDB

```js
const { MongoClient } = require('mongodb');
const client = new MongoClient(process.env.MONGODB_URI);
```

Collections map 1:1 to the JSON files above.
