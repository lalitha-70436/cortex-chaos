# CodeDynamos — Club Hub

A full-featured college tech club management platform with events, challenges, projects, leaderboard, gallery, and admin panel.

---

## 📁 Project Structure

```
codedynamos_project/
├── frontend/
│   └── index.html          ← Complete SPA (standalone, no build step needed)
├── backend/
│   ├── server.js           ← Express.js REST API
│   ├── database.js         ← Database abstraction layer (JSON files)
│   └── package.json        ← Node.js dependencies
└── database/
    ├── seed.json           ← Initial seed data (users, events, challenges, etc.)
    ├── SCHEMA.md           ← Full database schema documentation
    └── data/               ← Live JSON data files (auto-created on first run)
```

---

## 🚀 Quick Start

### Option A — Frontend Only (No Backend Needed)
The `frontend/index.html` is a fully self-contained SPA.
Just open it in any browser — it uses **localStorage** as its built-in database.

```bash
open frontend/index.html
```

**Demo credentials:**
- Member: click "Member Demo"
- Admin: click "Admin Demo"
- OAuth: click "Login with Google" or "Login with GitHub"

---

### Option B — With Backend API

#### 1. Install dependencies
```bash
cd backend
npm install
```

#### 2. Start the server
```bash
npm start
# or for auto-reload during development:
npm run dev
```

The API will run at `http://localhost:3001`

#### 3. Open the frontend
```bash
open ../frontend/index.html
```

---

## 🔌 API Endpoints

| Method | Endpoint                          | Auth     | Description                    |
|--------|-----------------------------------|----------|--------------------------------|
| POST   | /api/auth/login                   | —        | Email/password login           |
| POST   | /api/auth/signup                  | —        | Create new account             |
| POST   | /api/auth/oauth                   | —        | Google / GitHub OAuth          |
| GET    | /api/users                        | Admin    | List all users                 |
| PATCH  | /api/users/:handle/promote        | Admin    | Promote user to admin          |
| PATCH  | /api/users/:handle/ban            | Admin    | Ban a user                     |
| GET    | /api/events                       | —        | List events (filter by status) |
| POST   | /api/events                       | Admin    | Create event                   |
| DELETE | /api/events/:id                   | Admin    | Delete event                   |
| POST   | /api/events/:id/register          | Auth     | Register for an event          |
| PATCH  | /api/events/:id/feedback-toggle   | Admin    | Open/close feedback            |
| GET    | /api/challenges                   | —        | List challenges                |
| POST   | /api/challenges/:id/submit        | Auth     | Submit a solution              |
| GET    | /api/submissions                  | Admin    | View all submissions           |
| PATCH  | /api/submissions/:id/score        | Admin    | Score a submission             |
| GET    | /api/projects                     | —        | List projects                  |
| POST   | /api/projects/:id/like            | Auth     | Like/unlike a project          |
| PATCH  | /api/projects/:id/feature         | Admin    | Feature/unfeature project      |
| GET    | /api/team                         | —        | List team members              |
| GET    | /api/leaderboard                  | —        | Get leaderboard                |
| GET    | /api/suggestions                  | —        | List suggestions               |
| POST   | /api/suggestions                  | Auth     | Submit a suggestion            |
| POST   | /api/suggestions/:id/vote         | Auth     | Upvote a suggestion            |
| PATCH  | /api/suggestions/:id/status       | Admin    | Change suggestion status       |
| GET    | /api/feedback                     | Admin    | View all feedback              |
| POST   | /api/feedback                     | Auth     | Submit event feedback          |
| GET    | /api/announcements                | —        | List announcements             |
| POST   | /api/announcements                | Admin    | Post announcement              |
| GET    | /api/gallery                      | —        | Get gallery albums + photos    |
| GET    | /api/health                       | —        | Health check                   |

### Authentication Headers
For protected routes, send:
```
x-user-handle: alexj
```

---

## 🗄️ Database

Default: **JSON files** stored in `database/data/`
Auto-seeded from `database/seed.json` on first run.

To reset to seed data:
```bash
rm -rf database/data/
npm start   # re-creates from seed.json
```

See `database/SCHEMA.md` for full schema documentation.

### Upgrading to PostgreSQL / MongoDB
The `Database` class in `backend/database.js` is a clean abstraction.
Swap the `_read` / `_write` internals with your DB driver — all method signatures stay the same.

---

## 🔐 OAuth Setup (Production)

The current OAuth flow is a demo simulation. For real Google/GitHub OAuth:

1. Create OAuth apps at:
   - Google: https://console.developers.google.com
   - GitHub: https://github.com/settings/developers

2. Add your client IDs to environment variables:
   ```
   GOOGLE_CLIENT_ID=your_id
   GOOGLE_CLIENT_SECRET=your_secret
   GITHUB_CLIENT_ID=your_id
   GITHUB_CLIENT_SECRET=your_secret
   ```

3. Replace the `/api/auth/oauth` endpoint logic with token verification using the official SDKs.

---

## 🛠️ Tech Stack

| Layer    | Technology                          |
|----------|-------------------------------------|
| Frontend | Vanilla HTML/CSS/JS (no framework)  |
| Backend  | Node.js + Express.js                |
| Database | JSON files (swap for Mongo/Postgres)|
| Fonts    | Google Fonts (Bebas Neue, Syne, JetBrains Mono) |
| Images   | Unsplash (CDN)                      |

---

## ✨ Features

- 🏠 Home with animated stats & ticker
- 📅 Events with registration & feedback
- ⚡ Coding challenges with submission & scoring
- 🚀 Projects showcase with likes
- 👥 Team directory with badges
- 🏆 Leaderboard with XP system
- 🖼️ Photo gallery with albums
- 💡 Suggestions with voting
- 🎓 Certificates
- 📊 Progress tracker
- 🔐 Auth (email + Google/GitHub OAuth popup)
- ⚙️ Full admin panel

---

## 📄 License
MIT — CodeDynamos Club
